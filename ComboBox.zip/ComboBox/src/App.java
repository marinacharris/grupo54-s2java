import javax.swing.*;


import java.awt.event.*;

public class App extends JFrame implements ActionListener, ItemListener
{
    private JComboBox<String> combo1;
    
    public App(){
        setLayout(null);
        combo1 = new JComboBox<String>();
        combo1.setBounds(20,20,80,20);
        add(combo1);
        combo1.addItem("Título1");
        combo1.addItem("Título2");
        combo1.addItem("Título3");
        combo1.addItem("Título4");
        combo1.addItemListener(this);

    }

    public static void main(String[] args) throws Exception {
        App ventana = new App();
        ventana.setBounds(20,20,300,200);
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        if (e.getSource()== combo1){
            String opcion = combo1.getSelectedItem().toString();
            setTitle(opcion);
        }
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       
        
    }
}
