
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import java.awt.*;

public class App extends JFrame {
    JButton boton[];
    FlowLayout flowLayout1;
    JLabel display;
    JPanel panelBotones;
    GridLayout gridLayout1;
    JButton botonResultado;
    public App(){
        display();
        botones();
        botonResultado();
        ventana();
    }
    public static void main(String[] args) throws Exception {
       new App();
    }

    public void ventana(){
        flowLayout1 = new FlowLayout(FlowLayout.CENTER, 10,10);
        setLayout(flowLayout1);
        setTitle("Calculadora");
        setResizable(false);
        getContentPane().setBackground(Color.BLACK);
        setMinimumSize(new Dimension(260,410));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }
    public void display(){
        display = new JLabel("0");
        display.setPreferredSize(new Dimension(230,60));
        display.setBackground(Color.BLACK);
        display.setForeground(Color.GREEN);
        display.setBorder(new LineBorder(Color.GRAY));
        display.setFont(new Font("MONOSPACED", Font.PLAIN, 24));
        display.setHorizontalAlignment(SwingConstants.RIGHT);
        add(display);
    }
    public void botones(){
        panelBotones = new JPanel();
        panelBotones.setBackground(Color.BLACK);
        gridLayout1 = new GridLayout(4,4,10,10);
        panelBotones.setLayout(gridLayout1);
        add(panelBotones);
        boton = new JButton[16];
        String[] texto_botones = new String[]{"1","2","3","+","4","5","6","-","7","8","9","*","C","0",".","/"};
        for (int i = 0; i <16; i++) {
            boton[i] = new JButton(texto_botones[i]);
            boton[i].setBackground(Color.DARK_GRAY);
            boton[i].setPreferredSize(new Dimension(50,50));
            boton[i].setBorder(new LineBorder(Color.DARK_GRAY));
            boton[i].setForeground(Color.WHITE);
            panelBotones.add(boton[i]);
        }

    }
    public void botonResultado() {
        botonResultado = new JButton("RESULTADO");
        botonResultado.setPreferredSize(new Dimension(230,40));
        botonResultado.setFont(new Font("ARIAL", Font.PLAIN, 16));
        botonResultado.setBackground(Color.DARK_GRAY);
        botonResultado.setBorder(new LineBorder(Color.DARK_GRAY));
        botonResultado.setForeground(Color.WHITE);
        add(botonResultado);
    }

}
