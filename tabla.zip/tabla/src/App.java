import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class App extends JFrame{

    public App(){
        String[] nombreColumnas = {"Nombre", "Edad", "Extramjero"};
        Object[][] datos = {
            {"Ana", 25, false},
            {"Jean", 35, true},
            {"Carlos", 20, false},
        };
        // Crear modelo de datos
        DefaultTableModel modelo = new DefaultTableModel(datos,nombreColumnas);

        //Añadir columna nueva con datos al modelo
        String[] datosColumna = {"Contadora","Administrador","Ingeniero"};
        modelo.addColumn("Profesión", datosColumna);

        //Añadir filas
        Object[] datosFila ={"Sofía",30,true,"Enfermera"};
        modelo.addRow(datosFila);
        modelo.addRow(datosFila);
        modelo.addRow(datosFila);
        modelo.addRow(datosFila);
        modelo.addRow(datosFila);
        modelo.addRow(datosFila);
        modelo.addRow(datosFila);
        




        
        


        JTable tabla = new JTable(modelo);

        tabla.setPreferredScrollableViewportSize(new Dimension(250,100));
        JScrollPane scrollPane = new JScrollPane(tabla);
        getContentPane().add(scrollPane, BorderLayout.CENTER);




    }
    public static void main(String[] args) throws Exception {
        App ventana = new App();
        ventana.pack();
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(EXIT_ON_CLOSE);

    }
}
