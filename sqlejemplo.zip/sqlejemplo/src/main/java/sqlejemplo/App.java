package sqlejemplo;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.SQLException;

public class App 
{
    public static void main( String[] args ) throws SQLException
    {
        //SELECT
        String jdbcUrl = "jdbc:sqlite:C:\\Users\\robot\\Desktop\\hr.db";
        try{
            Connection conexion = DriverManager.getConnection(jdbcUrl); //conectando JDBC a sqlite
            String sql = "select * from employees e where salary > 10000";
            Statement stm = conexion.createStatement(); 
            ResultSet rs = stm.executeQuery(sql);
            while(rs.next()){
                Integer id = rs.getInt("employee_id");
                String nombre = rs.getString("first_name");
                String apellido = rs.getString("last_name");
                Double salario = rs.getDouble("salary");
                System.out.println(id + "\t" + nombre + "\t" + apellido + "\t" + salario);
            }
            rs.close();
            stm.close();
            conexion.close();
        }
        
    }
}
