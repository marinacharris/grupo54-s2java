import book.BookShop;

public class App 
{
    public static void main( String[] args )
    {
        new BookShop().start();
    }
}
