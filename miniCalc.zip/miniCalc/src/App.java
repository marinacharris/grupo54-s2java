import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.DimensionUIResource;

import java.awt.*;
import java.awt.event.*;
public class App extends JFrame implements ActionListener, ChangeListener
{
    private JTextField txtNum1, txtNum2;
    private JButton btnCalcular;
    private JLabel lblResultado;
    private JRadioButton btnSuma, btnResta, btnMul, btnDiv;
    private ButtonGroup btnGrupo;

    public App(){
        setLayout(new FlowLayout(FlowLayout.CENTER,5,5)); //Alineacion centra de los componentes con separacion de 5pixeles de forma vertical y horizontal
        txtNum1 = new JTextField();
        txtNum2 = new JTextField();
        txtNum1.setPreferredSize(new Dimension(100,30));
        txtNum2.setPreferredSize(new DimensionUIResource(100, 30));
        btnCalcular = new JButton("Calcular");
        btnCalcular.setPreferredSize(new Dimension(200,30));
        lblResultado = new JLabel("---");
        lblResultado.setPreferredSize(new Dimension(200,30));
        lblResultado.setFont(new Font("Arial", Font.BOLD, 20));
        btnSuma = new JRadioButton("+");
        btnSuma.setPreferredSize(new Dimension(40,20));
        btnResta = new JRadioButton("-");
        btnResta.setPreferredSize(new Dimension(40,20));
        btnMul = new JRadioButton("*");
        btnMul.setPreferredSize(new Dimension(40,20));
        btnDiv = new JRadioButton("/");
        btnDiv.setPreferredSize(new Dimension(40,20));
        btnGrupo = new ButtonGroup();

        add(lblResultado);
        add(txtNum1);
        add(txtNum2);
        add(btnCalcular);
        add(btnSuma);
        add(btnResta);
        add(btnMul);
        add(btnDiv);
        btnGrupo.add(btnSuma);
        btnGrupo.add(btnResta);
        btnGrupo.add(btnMul);
        btnGrupo.add(btnDiv);
        btnCalcular.addActionListener(this);
       


    }
    
    public static void main(String[] args) throws Exception {
        App ventana = new App();
        ventana.setBounds(20,20, 250, 180);
        ventana.setVisible(true);
        ventana.setTitle("Calculadora");
        ventana.setResizable(false);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    @Override
    public void stateChanged(ChangeEvent e) {
            Double resultado= 0.0;
            Double num1 = Double.parseDouble(txtNum1.getText());
            Double num2 = Double.parseDouble(txtNum2.getText());
            if (btnSuma.isSelected()){
                resultado = num1 +  num2;
            }
            lblResultado.setText(String.valueOf(resultado));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()== btnCalcular){
            Double resultado= 0.0;
            Double num1 = Double.parseDouble(txtNum1.getText());
            Double num2 = Double.parseDouble(txtNum2.getText());
            if (btnSuma.isSelected()){
                resultado = num1 +  num2;
            }
            if (btnResta.isSelected()){
                resultado = num1 - num2;
            }
            if (btnMul.isSelected()){
                resultado = num1*num2;
            }
            if (btnDiv.isSelected()){
                resultado = num1 / num2;
            }
            lblResultado.setText(String.valueOf(resultado));

        }
        
    }
}
